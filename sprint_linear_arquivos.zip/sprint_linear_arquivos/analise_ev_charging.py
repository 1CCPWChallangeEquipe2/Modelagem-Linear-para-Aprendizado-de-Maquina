# =============================================================================
# EV Challenge 2026 — FIAP + GoodWe
# Sprint 1 — Análise Estatística: Tabelas de Distribuição de Frequências
# Base de dados: Residential EV Charging from Apartment Buildings (Kaggle)
# Fonte: https://www.kaggle.com/datasets/anshtanwar/residential-ev-chargingfrom-apartment-buildings
# =============================================================================

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import warnings
warnings.filterwarnings("ignore")

# ── Configurações visuais globais ─────────────────────────────────────────────
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.titlesize": 13,
    "axes.labelsize": 11,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "figure.dpi": 130,
})

AZUL_FIAP  = "#1F3864"
VERM_GW    = "#E63946"
CINZA      = "#6C757D"
VERDE      = "#2A9D8F"
AMARELO    = "#E9C46A"

# =============================================================================
# 1. LEITURA DA BASE DE DADOS
# =============================================================================
df = pd.read_csv("ev_charging_dataset.csv")

print("=" * 65)
print("  EV CHALLENGE 2026 — SPRINT 1 | FIAP + GoodWe")
print("=" * 65)
print(f"\n  Registros carregados : {len(df):>6}")
print(f"  Colunas              : {len(df.columns):>6}")
print(f"  Período              : {df['created'].min()[:10]}  →  {df['created'].max()[:10]}")
print()

# =============================================================================
# 2. TABELA DE FREQUÊNCIAS — VARIÁVEL QUANTITATIVA DISCRETA
#    Variável escolhida: userSessionCount (nº acumulado de sessões por usuário)
# =============================================================================

print("─" * 65)
print("  TABELA 1 — Variável Quantitativa DISCRETA")
print("  userSessionCount: Nº acumulado de sessões do usuário")
print("─" * 65)

# Agrupar em faixas para melhor visualização (classes de 5)
bins_disc  = [0, 5, 10, 15, 20, 25, 30]
labels_disc = ["1–5", "6–10", "11–15", "16–20", "21–25", "26–30"]

df["faixa_sessoes"] = pd.cut(
    df["userSessionCount"],
    bins=bins_disc,
    labels=labels_disc,
    right=True
)

freq_disc = (
    df["faixa_sessoes"]
    .value_counts()
    .sort_index()
    .rename_axis("Faixa de Sessões")
    .reset_index()
)
freq_disc.columns = ["Faixa de Sessões", "Frequência Absoluta (fi)"]
freq_disc["Frequência Relativa (fri)"] = (
    freq_disc["Frequência Absoluta (fi)"] / len(df) * 100
).round(2)
freq_disc["Freq. Relativa (%)"] = freq_disc["Frequência Relativa (fri)"].map(
    lambda x: f"{x:.2f}%"
)
freq_disc["Freq. Acumulada (Fi)"] = freq_disc["Frequência Absoluta (fi)"].cumsum()
freq_disc["Freq. Acum. Rel. (%)"] = (
    freq_disc["Freq. Acumulada (Fi)"] / len(df) * 100
).round(2).map(lambda x: f"{x:.2f}%")

print(freq_disc[["Faixa de Sessões",
                  "Frequência Absoluta (fi)",
                  "Freq. Relativa (%)",
                  "Freq. Acumulada (Fi)",
                  "Freq. Acum. Rel. (%)"]].to_string(index=False))
print(f"\n  Total de observações: {freq_disc['Frequência Absoluta (fi)'].sum()}")

# -- INSIGHTS VARIÁVEL DISCRETA ------------------------------------------------

# Insight 1: distribuição da fidelidade dos usuários
faixa_moda = freq_disc.loc[freq_disc["Frequência Absoluta (fi)"].idxmax(), "Faixa de Sessões"]
perc_moda  = freq_disc.loc[freq_disc["Frequência Absoluta (fi)"].idxmax(), "Freq. Relativa (%)"]

# Insight 2: usuários de baixo uso (1–5 sessões) vs alto uso (21–30 sessões)
baixo_uso = freq_disc.loc[freq_disc["Faixa de Sessões"] == "1–5", "Frequência Relativa (fri)"].values[0]
alto_uso  = (
    freq_disc.loc[freq_disc["Faixa de Sessões"].isin(["21–25","26–30"]),
                  "Frequência Relativa (fri)"].sum()
)

# INSIGHT 1: A faixa mais frequente revela o perfil dominante de uso
print(f"\n  # INSIGHT 1 — Perfil dominante de uso:")
print(f"  # A faixa '{faixa_moda}' sessões é a mais comum ({perc_moda} das sessões).")
print(f"  # Isso indica que a maioria dos usuários usa o carregador com frequência")
print(f"  # moderada. Para a GoodWe, esse perfil justifica tarifas mensais ou planos")
print(f"  # de assinatura com franquias de sessões — modelo de negócio recorrente.")

# INSIGHT 2: Concentração de usuários eventuais vs recorrentes
print(f"\n  # INSIGHT 2 — Usuários eventuais vs recorrentes:")
print(f"  # {baixo_uso:.1f}% das sessões pertencem a usuários com apenas 1–5 recargas acumuladas")
print(f"  # (uso esporádico), enquanto {alto_uso:.1f}% são de usuários com 21+ sessões (heavy users).")
print(f"  # A GoodWe pode criar programas de fidelidade para converter usuários eventuais")
print(f"  # em recorrentes, aumentando a utilização da infraestrutura instalada.")

# =============================================================================
# 3. TABELA DE FREQUÊNCIAS — VARIÁVEL QUANTITATIVA CONTÍNUA
#    Variável escolhida: kwhTotal (energia consumida por sessão)
# =============================================================================

print("\n" + "─" * 65)
print("  TABELA 2 — Variável Quantitativa CONTÍNUA")
print("  kwhTotal: Energia total consumida por sessão (kWh)")
print("─" * 65)

# Regra de Sturges: k = 1 + 3.322 * log10(n)
n       = len(df)
k       = int(np.ceil(1 + 3.322 * np.log10(n)))   # número de classes
amp_tot = df["kwhTotal"].max() - df["kwhTotal"].min()
h       = amp_tot / k                               # amplitude de classe

print(f"\n  n = {n}  |  k (Sturges) = {k}  |  amplitude total = {amp_tot:.2f}  |  h = {h:.2f} kWh")

bins_cont  = np.linspace(df["kwhTotal"].min(), df["kwhTotal"].max(), k + 1)
labels_cont = [
    f"{bins_cont[i]:.1f} ├── {bins_cont[i+1]:.1f}"
    for i in range(len(bins_cont) - 1)
]

df["classe_kwh"] = pd.cut(
    df["kwhTotal"],
    bins=bins_cont,
    labels=labels_cont,
    include_lowest=True
)

freq_cont = (
    df["classe_kwh"]
    .value_counts()
    .sort_index()
    .rename_axis("Classe (kWh)")
    .reset_index()
)
freq_cont.columns = ["Classe (kWh)", "Frequência Absoluta (fi)"]
freq_cont["Freq. Relativa (fri)"] = (
    freq_cont["Frequência Absoluta (fi)"] / n * 100
).round(2)
freq_cont["Freq. Relativa (%)"] = freq_cont["Freq. Relativa (fri)"].map(
    lambda x: f"{x:.2f}%"
)
freq_cont["Freq. Acumulada (Fi)"] = freq_cont["Frequência Absoluta (fi)"].cumsum()
freq_cont["Freq. Acum. Rel. (%)"] = (
    freq_cont["Freq. Acumulada (Fi)"] / n * 100
).round(2).map(lambda x: f"{x:.2f}%")

print(freq_cont[["Classe (kWh)",
                  "Frequência Absoluta (fi)",
                  "Freq. Relativa (%)",
                  "Freq. Acumulada (Fi)",
                  "Freq. Acum. Rel. (%)"]].to_string(index=False))
print(f"\n  Total de observações: {freq_cont['Frequência Absoluta (fi)'].sum()}")

# -- INSIGHTS VARIÁVEL CONTÍNUA -----------------------------------------------

# Insight 1: classe modal (maior concentração de consumo)
classe_modal = freq_cont.loc[
    freq_cont["Frequência Absoluta (fi)"].idxmax(), "Classe (kWh)"
]
perc_modal = freq_cont.loc[
    freq_cont["Frequência Absoluta (fi)"].idxmax(), "Freq. Relativa (%)"]

# Insight 2: percentual acima de 30 kWh (alto consumo)
perc_alto_kwh = freq_cont.loc[
    freq_cont["Classe (kWh)"].astype(str).str.startswith(
        tuple([f"{v:.1f}" for v in bins_cont if v >= 30])
    ), "Freq. Relativa (fri)"
].sum()

media_kwh  = df["kwhTotal"].mean()
mediana_kwh = df["kwhTotal"].median()

# INSIGHT 1: Faixa de maior consumo → dimensionamento de infraestrutura
print(f"\n  # INSIGHT 1 — Faixa dominante de consumo por sessão:")
print(f"  # A classe '{classe_modal}' kWh concentra {perc_modal} das sessões.")
print(f"  # Média = {media_kwh:.2f} kWh | Mediana = {mediana_kwh:.2f} kWh.")
print(f"  # Para a GoodWe, esse dado define o dimensionamento ideal dos carregadores:")
print(f"  # um modelo de 7–11 kW já atende a maioria das sessões residenciais,")
print(f"  # sem necessidade de infraestrutura de alta potência em todos os pontos.")

# INSIGHT 2: Detecção de padrão assimétrico (cauda direita)
p25 = df["kwhTotal"].quantile(0.25)
p75 = df["kwhTotal"].quantile(0.75)
print(f"\n  # INSIGHT 2 — Assimetria e planejamento de demanda:")
print(f"  # 50% das sessões consomem entre {p25:.1f} e {p75:.1f} kWh (IQR = {p75-p25:.1f} kWh).")
print(f"  # A distribuição é assimétrica à direita: existem sessões de alto consumo")
print(f"  # que puxam a média ({media_kwh:.2f}) acima da mediana ({mediana_kwh:.2f}).")
print(f"  # Isso indica a presença de heavy chargers — usuários que consomem muito")
print(f"  # em cada sessão — que devem ser monitorados pelo algoritmo de controle")
print(f"  # de demanda do ChargeGrid Intelligence para evitar sobrecarga da rede.")

# =============================================================================
# 4. VISUALIZAÇÕES
# =============================================================================

fig, axes = plt.subplots(2, 2, figsize=(15, 10))
fig.suptitle(
    "EV Challenge 2026 — FIAP + GoodWe\nAnálise de Sessões de Recarga Residencial",
    fontsize=15, fontweight="bold", color=AZUL_FIAP, y=1.01
)

# ── Gráfico 1: Histograma kwhTotal ────────────────────────────────────────────
ax1 = axes[0, 0]
ax1.hist(df["kwhTotal"], bins=k, color=AZUL_FIAP, edgecolor="white", alpha=0.85)
ax1.axvline(media_kwh, color=VERM_GW, linewidth=2, linestyle="--", label=f"Média: {media_kwh:.2f} kWh")
ax1.axvline(mediana_kwh, color=VERDE, linewidth=2, linestyle=":", label=f"Mediana: {mediana_kwh:.2f} kWh")
ax1.set_title("Distribuição de Energia por Sessão (kWh)", fontweight="bold")
ax1.set_xlabel("Energia Consumida (kWh)")
ax1.set_ylabel("Frequência Absoluta")
ax1.legend(fontsize=9)
ax1.grid(axis="y", alpha=0.3)

# ── Gráfico 2: Barras userSessionCount ───────────────────────────────────────
ax2 = axes[0, 1]
bars = ax2.bar(
    freq_disc["Faixa de Sessões"],
    freq_disc["Frequência Absoluta (fi)"],
    color=[AZUL_FIAP, "#2E75B6", VERDE, AMARELO, CINZA, VERM_GW],
    edgecolor="white", width=0.6
)
for bar in bars:
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
             str(int(bar.get_height())), ha="center", va="bottom", fontsize=9, fontweight="bold")
ax2.set_title("Distribuição de Sessões Acumuladas por Usuário", fontweight="bold")
ax2.set_xlabel("Faixa de Sessões")
ax2.set_ylabel("Frequência Absoluta")
ax2.grid(axis="y", alpha=0.3)

# ── Gráfico 3: Ogiva kwhTotal ─────────────────────────────────────────────────
ax3 = axes[1, 0]
acum = freq_cont["Freq. Acumulada (Fi)"].values
midpoints = [
    (bins_cont[i] + bins_cont[i+1]) / 2
    for i in range(len(bins_cont) - 1)
]
ax3.plot(midpoints, acum, color=VERM_GW, marker="o", linewidth=2.5,
         markersize=5, label="Frequência Acumulada")
ax3.fill_between(midpoints, acum, alpha=0.15, color=VERM_GW)
ax3.axhline(n * 0.50, color=CINZA, linewidth=1.2, linestyle="--", alpha=0.7, label="50% (mediana)")
ax3.axhline(n * 0.75, color=VERDE, linewidth=1.2, linestyle="--", alpha=0.7, label="75% (Q3)")
ax3.set_title("Ogiva — Frequência Acumulada (kWh Total)", fontweight="bold")
ax3.set_xlabel("Energia Consumida (kWh)")
ax3.set_ylabel("Frequência Acumulada")
ax3.legend(fontsize=9)
ax3.grid(alpha=0.3)

# ── Gráfico 4: Distribuição por dia da semana ─────────────────────────────────
ax4 = axes[1, 1]
order = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
day_counts = df["weekday"].value_counts().reindex(order).fillna(0)
short_days  = ["Seg","Ter","Qua","Qui","Sex","Sáb","Dom"]
colors_days = [AZUL_FIAP]*5 + [VERM_GW]*2
bars2 = ax4.bar(short_days, day_counts.values, color=colors_days, edgecolor="white", width=0.6)
for bar in bars2:
    ax4.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
             str(int(bar.get_height())), ha="center", va="bottom", fontsize=9, fontweight="bold")
ax4.set_title("Sessões por Dia da Semana", fontweight="bold")
ax4.set_xlabel("Dia da Semana")
ax4.set_ylabel("Nº de Sessões")
ax4.grid(axis="y", alpha=0.3)

plt.tight_layout()

plt.savefig("graficos_ev_charging.png", dpi=150, bbox_inches="tight", facecolor="white")


plt.close()
print("\n  Gráficos salvos com sucesso!")

# =============================================================================
# 5. EXPORTAR TABELAS PARA CSV (uso no relatório)
# =============================================================================
freq_disc.to_csv("tabela_freq_discreta.csv", index=False)
freq_cont.to_csv("tabela_freq_continua.csv", index=False)
print("  Tabelas exportadas para CSV.")
print("\n  ✓ Script finalizado com sucesso!")
